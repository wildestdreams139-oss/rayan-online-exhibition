# RAYAN ONLINE EXHIBITION — 最终策展总表

**策展版本：V1 / 24 件主展作品 + 4 件档案材料**  
**核心原则：** 主展以手绘插画作为统一视觉语言；画史实验区作为风格拓展；HORROR 只进入 Secret Room，避免破坏主展气质。

## ROOM 00 — ARCHIVE / 原点档案（不计入 24 件主展）

| 编号 | 中文标题 | 英文标题 | 来源文件 | 展示方式 |
|---|---|---|---|---|
| A00 | 原点 | The Original | `original.jpg` | 原始收藏实拍，单独玻璃柜式展示 |
| A01 | 第一次转化 | First Transformation | `01_first-transformation.webp` | 早期视觉档案 |
| A02 | 涂鸦画布 | Graffiti Canvas | `04_graffiti-canvas.webp` | 早期风格实验 |
| A03 | 咖啡巷 | Café Alley — Early Study | `07_cafe-alley.webp` | 生活场景档案 |

## GALLERY 01 — SAME KID, DIFFERENT DAYS / 同一个孩子，不同日常

| 编号 | 中文标题 | 英文标题 | 来源文件 | 媒介 / 风格 | 展示备注 |
|---|---|---|---|---|---|
| R01 | 窗边发呆 | Window Daydream | `01_window_daydream.png` | 手绘水彩 / 水粉插画 | 开场安静作品，大幅 |
| R02 | 石阶停驻 | Stair Rest | `02_stair_rest.png` | 手绘生活插画 | 与 R01 形成自然光组 |
| R03 | 咖啡巷 | Café Alley | `Chibi Boy Rayan in a Cozy Café Alley.png` | 手绘街景插画 | 主展代表作之一 |
| R04 | 工作室角落 | Studio Corner | `04_studio_corner.png` | 手绘创作场景 | 配“Rayan 的创作桌”馆签 |
| R05 | 傍晚回望 | Evening Walk | `05_evening_alley_walk.png` | 黄昏叙事插画 | 纵向单幅，大留白 |
| R06 | 长椅小憩 | Bench Rest | `06_bench_rest.png` | 公园生活插画 | 节奏缓冲作品 |
| R07 | 同一个孩子，不同世界 | Same Kid, Different World | `Rayan: Same Kid, Different World.png` | 街头手绘 / 海报插画 | 主展标题视觉 |
| R08 | 无事发生的下午 | Nothing Much Today | `Same Kid, Different World.png` | 室内手绘 / 音乐生活 | 轻松收束 Gallery 01 |

## GALLERY 02 — ACROSS TIME / 穿越画史

| 编号 | 中文标题 | 英文标题 | 来源文件 | 媒介 / 风格 | 展示备注 |
|---|---|---|---|---|---|
| R09 | 溪山独坐 | Sitting by the Quiet Stream | `rayan_s_quiet_ink_wash_riverside.png` | 东方水墨山水 | 留白最多，单独一面墙 |
| R10 | 潮声 | Sound of Waves | `ukiyo_e_waves_with_rayan_and_frog.png` | 木版画 / 浮世绘语言 | 与 R09 对照展示 |
| R11 | 云阙 | Echoes of the Wall | `grumpy_chibi_boy_in_dunhuang_fresco.png` | 壁画 / 矿物色 | 暖色展墙 |
| R12 | 红椅上的孩子 | Boy in the Red Chair | `grumpy_frog_companion_toy_in_velvet_chair.png` | 古典油画肖像 | 深色墙、聚光灯效果 |
| R13 | 花园午后 | Afternoon in the Garden | `grumpy_boy_and_frog_in_golden_garden.png` | 印象派光色 | 明亮过渡区 |
| R14 | 月下河岸 | Moonlit Riverside | `moonlit_riverside_with_frog_companion.png` | 后印象派夜景 | 深蓝展墙 |
| R15 | 百合框景 | Framed by Lilies | `art_nouveau_lily_portrait_of_rayan.png` | Art Nouveau / 新艺术 | 装饰性作品，竖幅 |
| R16 | 几何情绪 | Geometric Mood | `grumpy_boy_and_frog_in_a_modernist_gallery.png` | 现代主义 / 几何构成 | Gallery 02 尾声 |

## SECRET ROOM — AFTER HOURS / HORROR COLLECTION

> 仅通过隐藏入口或密码进入。普通展厅不预告完整画面，只显示“AFTER HOURS”门牌。

| 编号 | 中文标题 | 英文标题 | 来源文件 | 恐怖类型 | 展示备注 |
|---|---|---|---|---|---|
| S01 | 旧宅来客 | The Visitor Upstairs | `moonlit_mansion_with_frog_companion.png` | 哥特旧宅 / 幽灵 | Secret Room 开场 |
| S02 | 镜中第二个我 | The Other One in the Mirror | `haunted_mirror_and_the_frog_capped_boy.png` | 镜像恐怖 | 低亮度单幅 |
| S03 | 空病房 | Ward 13 | `frog_cap_in_the_haunted_hospital.png` | 废弃医院 | 冷白灯视觉 |
| S04 | 闭园之后 | After the Carnival | `rayan_in_the_haunted_carnival.png` | 废弃游乐园 | 红黑暖光，压迫感最强之一 |
| S05 | 黑色圣堂 | The Hollow Chapel | `rayan_in_the_haunted_chapel_library.png` | 哥特教堂 / 禁书 | 烛光墙面 |
| S06 | 地下回声 | Echoes Below | `lantern_light_in_the_catacombs.png` | 地下墓穴 / 追逐 | 狭长纵向展示 |
| S07 | 楼梯尽头 | At the Top of the Stairs | `lantern_bearer_on_the_haunted_staircase.png` | 鬼影楼梯 | 作为跳转高潮 |
| S08 | 白花墓园 | The Garden of Quiet Faces | `moonlit_descent_through_the_haunted_cemetery.png` | 墓园 / 月夜幽灵 | Secret Room 最终作品 |

## 网站中的策展顺序

**ROOM 00 → GALLERY 01 → GALLERY 02 → PHOTO SPOT / GUESTBOOK → SECRET ROOM**

- Gallery 01 是整个展览的核心身份：统一手绘 Rayan 世界。
- Gallery 02 用不同历史绘画语言做“特别展”，但每张仍只保留一种明确画风。
- Secret Room 与主展完全分色：深黑、暗蓝、旧金色；不在普通展厅大量剧透。
- 原先其余作品保留在 Curator Archive，不进入首轮正式挂展，之后可做轮换展。

## 首轮不挂展 / 保留备用

`quiet_tones_grumpy_boy_and_frog.png`、`chibi_boy_at_the_moon_gate.png`、`chibi_frog_companion_in_the_secret_room.png`、`rainy_gothic_alley_companions.png`、`rayan_and_the_haunted_staircase.png`、`moonlit_attic_and_the_haunted_mirror.png` 等保留作后续轮换或季节限定，不删除。

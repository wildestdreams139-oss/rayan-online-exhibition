# RAYAN ONLINE EXHIBITION v4 — 上线就绪

这版已经准备好直接部署到 Vercel，并接入 Supabase 的共享签名墙与共享打卡墙。

## 上线后会得到
- 一个可直接发给朋友的公网网址
- 电子邀请函 / 独立票号 / Access Code
- 共享 Guestbook：A 留言后 B 可以看到
- 共享 Check-in Wall：访客可发布自己的纪念卡
- 开馆倒计时、闭馆 Archive、Secret Room、Museum Passport 均保留

## 当前还差两项账号授权
1. Vercel：负责把整套网站发布到公网
2. Supabase：负责共享留言与共享打卡数据

授权完成后即可：
1. 创建 Supabase project
2. 执行 `supabase/schema.sql`
3. 将 Project URL 与 public anon key 写入 `assets/shared-config.js`
4. 部署本目录到 Vercel
5. 返回正式公网 URL

## 正式开馆时间
当前仍保留 PREVIEW 模式，避免在没有确认日期时错误锁馆。
正式上线后只需在 `assets/app.js` 顶部改为：
`mode: 'LIVE'`
并填写实际开馆与闭馆时间。
